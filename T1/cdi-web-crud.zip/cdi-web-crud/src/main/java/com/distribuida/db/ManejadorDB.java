package com.distribuida.db;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

@ApplicationScoped
public class ManejadorDB {
	/**
	 * M�todo productor, para manejar pool de conexiones
	 * 
	 * @return Datasource
	 */
	@Produces
	@ApplicationScoped
	public DataSource db() {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("org.postgresql.Driver"); // driver de postgres
		bds.setUrl("jdbc:postgresql://localhost:5432/distribuida"); // Cadena de conexi�n
		bds.setUsername("postgres"); 
		bds.setPassword("admin"); 
		bds.setMaxTotal(10); // m�ximo de conexiones
		bds.setMaxIdle(5); // Empieza con 5 conexiones y va subiendo hasta 10
		return bds;
	}
	
	
}
